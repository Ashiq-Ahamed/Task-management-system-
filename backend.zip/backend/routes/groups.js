const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const pool = require('../config/database');
const authMiddleware = require('../middleware/auth');

const getAnyTenantId = async () => {
  const [rows] = await pool.query('SELECT id FROM tenants ORDER BY id ASC LIMIT 1');
  return rows.length ? rows[0].id : null;
};

const ensureTenantId = async () => {
  const existing = await getAnyTenantId();
  if (existing) return existing;

  const [columns] = await pool.query('SHOW COLUMNS FROM tenants');
  const required = columns.filter((c) => {
    const hasDefault = c.Default !== null;
    const allowsNull = c.Null === 'YES';
    const autoIncrement = String(c.Extra || '').toLowerCase().includes('auto_increment');
    return !hasDefault && !allowsNull && !autoIncrement;
  });

  const insertColumns = [];
  const insertValues = [];
  const placeholders = [];

  for (const col of required) {
    const field = String(col.Field || '').toLowerCase();
    const type = String(col.Type || '').toLowerCase();

    insertColumns.push(col.Field);

    if (field.includes('name') || field.includes('title')) {
      insertValues.push('Default Tenant');
      placeholders.push('?');
      continue;
    }

    if (field.includes('status')) {
      insertValues.push('active');
      placeholders.push('?');
      continue;
    }

    if (type.includes('date') || type.includes('time') || type.includes('timestamp')) {
      placeholders.push('NOW()');
      continue;
    }

    if (type.includes('int') || type.includes('decimal') || type.includes('float') || type.includes('double')) {
      insertValues.push(1);
      placeholders.push('?');
      continue;
    }

    insertValues.push('default');
    placeholders.push('?');
  }

  if (insertColumns.length) {
    const sql = `INSERT INTO tenants (${insertColumns.join(', ')}) VALUES (${placeholders.join(', ')})`;
    const [result] = await pool.query(sql, insertValues);
    return result.insertId || null;
  }

  const [result] = await pool.query('INSERT INTO tenants () VALUES ()');
  return result.insertId || null;
};

/* =========================================
   GET ALL GROUPS
========================================= */
router.get('/', authMiddleware, async (req, res) => {
  try {
    const [groups] = await pool.query(
      'SELECT * FROM groups ORDER BY name'
    );

    console.log(`Fetched ${groups.length} groups`);
    res.json(groups);
  } catch (error) {
    console.error('Error fetching groups:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

/* =========================================
   CREATE GROUP
========================================= */
router.post(
  '/',
  [
    authMiddleware,
    body('name').notEmpty().withMessage('Name is required'),
    body('status').optional().isIn(['active', 'inactive']).withMessage('Invalid status')
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { name, status = 'active' } = req.body;
      const tenantId = await ensureTenantId();
      if (!tenantId) {
        return res.status(500).json({ message: 'Failed to resolve tenant for group creation' });
      }

      console.log('Creating group:', { name, status });

      const [result] = await pool.query(
        'INSERT INTO groups (tenant_id, name, status) VALUES (?, ?, ?)',
        [tenantId, name, status]
      );

      res.status(201).json({
        message: 'Group created successfully',
        groupId: result.insertId
      });
    } catch (error) {
      console.error('Error creating group:', error);
      res.status(500).json({ message: 'Server error' });
    }
  }
);

/* =========================================
   UPDATE GROUP
========================================= */
router.put('/:id', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    const { name, status } = req.body;

    const updateFields = [];
    const updateValues = [];

    if (name) {
      updateFields.push('name = ?');
      updateValues.push(name);
    }
    if (status) {
      if (!['active', 'inactive'].includes(status)) {
        return res.status(400).json({ message: 'Invalid status' });
      }
      updateFields.push('status = ?');
      updateValues.push(status);
    }

    if (updateFields.length === 0) {
      return res.status(400).json({ message: 'No fields to update' });
    }

    updateValues.push(id);

    const [result] = await pool.query(
      `UPDATE groups SET ${updateFields.join(', ')} WHERE id = ?`,
      updateValues
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Group not found' });
    }

    console.log(`Group ${id} updated`);
    res.json({ message: 'Group updated successfully' });
  } catch (error) {
    console.error('Error updating group:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

/* =========================================
   DELETE GROUP
========================================= */
router.delete('/:id', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params;

    const [result] = await pool.query(
      'DELETE FROM groups WHERE id = ?',
      [id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Group not found' });
    }

    console.log(`Group ${id} deleted`);
    res.json({ message: 'Group deleted successfully' });
  } catch (error) {
    console.error('Error deleting group:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
