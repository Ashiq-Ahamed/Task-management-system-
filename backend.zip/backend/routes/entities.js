const express = require('express');
const router = express.Router();
const pool = require('../config/database');
const authMiddleware = require('../middleware/auth');
const { body, validationResult } = require('express-validator');

let entityColumnsCache = null;
let entityColumnsCacheAt = 0;
const ENTITY_COLUMNS_TTL_MS = 30000;

const getEntityColumnSet = async () => {
  const now = Date.now();
  if (entityColumnsCache && now - entityColumnsCacheAt < ENTITY_COLUMNS_TTL_MS) {
    return entityColumnsCache;
  }

  const [rows] = await pool.query('SHOW COLUMNS FROM entities');
  const columns = new Set(rows.map((r) => r.Field));

  entityColumnsCache = columns;
  entityColumnsCacheAt = now;
  return columns;
};

const getAnyTenantId = async () => {
  const [rows] = await pool.query('SELECT id FROM tenants ORDER BY id ASC LIMIT 1');
  return rows.length ? rows[0].id : null;
};

const ensureTenantId = async () => {
  const existing = await getAnyTenantId();
  if (existing) return existing;

  const [columns] = await pool.query('SHOW COLUMNS FROM tenants');
  const required = columns.filter((c) => {
    const hasDefault = c.Default !== null;
    const allowsNull = c.Null === 'YES';
    const autoIncrement = String(c.Extra || '').toLowerCase().includes('auto_increment');
    return !hasDefault && !allowsNull && !autoIncrement;
  });

  const insertColumns = [];
  const insertValues = [];
  const placeholders = [];

  for (const col of required) {
    const field = String(col.Field || '').toLowerCase();
    const type = String(col.Type || '').toLowerCase();

    insertColumns.push(col.Field);

    if (field.includes('name') || field.includes('title')) {
      insertValues.push('Default Tenant');
      placeholders.push('?');
      continue;
    }

    if (field.includes('status')) {
      insertValues.push('active');
      placeholders.push('?');
      continue;
    }

    if (type.includes('date') || type.includes('time') || type.includes('timestamp')) {
      placeholders.push('NOW()');
      continue;
    }

    if (type.includes('int') || type.includes('decimal') || type.includes('float') || type.includes('double')) {
      insertValues.push(1);
      placeholders.push('?');
      continue;
    }

    insertValues.push('default');
    placeholders.push('?');
  }

  if (insertColumns.length) {
    const sql = `INSERT INTO tenants (${insertColumns.join(', ')}) VALUES (${placeholders.join(', ')})`;
    const [result] = await pool.query(sql, insertValues);
    return result.insertId || null;
  }

  const [result] = await pool.query('INSERT INTO tenants () VALUES ()');
  return result.insertId || null;
};

/* =========================================
   GET ALL ENTITIES
========================================= */
router.get('/', authMiddleware, async (req, res) => {
  try {
    const [entities] = await pool.query('SELECT * FROM entities ORDER BY name');

    res.json({ success: true, data: entities });
  } catch (err) {
    console.error('Get Entities Error:', err);
    res.status(500).json({ success: false, message: err.sqlMessage || err.message || 'Server error while fetching entities' });
  }
});

/* =========================================
   CREATE ENTITY
========================================= */
router.post(
  '/',
  [
    authMiddleware,
    body('name').trim().notEmpty().withMessage('Entity name is required'),
    body('status').optional().isIn(['active', 'inactive']).withMessage('Invalid status value')
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ success: false, errors: errors.array() });
      }

      if (!req.user || !req.user.id) {
        return res.status(401).json({ success: false, message: 'User authentication failed' });
      }

      const { id: user_id } = req.user;
      const { name, status = 'active' } = req.body;
      const columns = await getEntityColumnSet();

      if (!columns.has('name')) {
        return res.status(500).json({ success: false, message: 'entities table must include name column' });
      }
      const insertColumns = ['name'];
      const insertValues = [name.trim()];
      const placeholders = ['?'];

      if (columns.has('status')) {
        insertColumns.push('status');
        insertValues.push(status);
        placeholders.push('?');
      }

      if (columns.has('created_by')) {
        insertColumns.push('created_by');
        insertValues.push(user_id);
        placeholders.push('?');
      }

      if (columns.has('tenant_id')) {
        const tenantId = await ensureTenantId();
        if (!tenantId) {
          return res.status(500).json({
            success: false,
            message: "entities.tenant_id is required, and tenant bootstrap failed. Add one tenants row manually or remove entities.tenant_id FK."
          });
        }
        insertColumns.push('tenant_id');
        insertValues.push(tenantId);
        placeholders.push('?');
      }

      if (columns.has('created_at')) {
        insertColumns.push('created_at');
        placeholders.push('NOW()');
      }

      if (columns.has('updated_at')) {
        insertColumns.push('updated_at');
        placeholders.push('NOW()');
      }

      const sql = `INSERT INTO entities (${insertColumns.join(', ')}) VALUES (${placeholders.join(', ')})`;
      const [result] = await pool.query(sql, insertValues);

      res.status(201).json({
        success: true,
        message: 'Entity created successfully',
        entity: { id: result.insertId, name: name.trim(), status: columns.has('status') ? status : null }
      });
    } catch (err) {
      console.error('Create Entity Error:', err);
      if (err.code === 'ER_DUP_ENTRY') {
        return res.status(409).json({ success: false, message: 'Entity name already exists' });
      }
      if (err.code === 'ER_NO_DEFAULT_FOR_FIELD' && err.sqlMessage?.includes("'tenant_id'")) {
        return res.status(500).json({
          success: false,
          message: "Database schema requires tenant_id for entities, but this app is tenant-agnostic. Remove entities.tenant_id or make it nullable."
        });
      }
      if (err.code === 'ER_NO_REFERENCED_ROW_2' && err.sqlMessage?.includes('entities_ibfk_1')) {
        return res.status(500).json({
          success: false,
          message: "Invalid entities.tenant_id foreign key. Remove tenant FK if you don't use tenants."
        });
      }
      res.status(500).json({ success: false, message: err.sqlMessage || err.message || 'Server error while creating entity' });
    }
  }
);

/* =========================================
   UPDATE ENTITY
========================================= */
router.put(
  '/:id',
  [
    authMiddleware,
    body('name').optional().notEmpty().withMessage('Name cannot be empty'),
    body('status').optional().isIn(['active', 'inactive']).withMessage('Invalid status value')
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ success: false, errors: errors.array() });
      }

      const { id } = req.params;
      const { name, status } = req.body;
      const columns = await getEntityColumnSet();

      const updateFields = [];
      const updateValues = [];

      if (columns.has('name') && name && name.trim()) {
        updateFields.push('name = ?');
        updateValues.push(name.trim());
      }

      if (columns.has('status') && status) {
        updateFields.push('status = ?');
        updateValues.push(status);
      }

      if (columns.has('updated_at')) {
        updateFields.push('updated_at = NOW()');
      }

      if (!updateFields.length) {
        return res.status(400).json({ success: false, message: 'No valid fields to update' });
      }

      const sql = `UPDATE entities SET ${updateFields.join(', ')} WHERE id = ?`;
      updateValues.push(id);

      const [result] = await pool.query(sql, updateValues);

      if (result.affectedRows === 0) {
        return res.status(404).json({ success: false, message: 'Entity not found' });
      }

      res.json({ success: true, message: 'Entity updated successfully' });
    } catch (err) {
      console.error('Update Entity Error:', err);
      if (err.code === 'ER_DUP_ENTRY') {
        return res.status(409).json({ success: false, message: 'Entity name already exists' });
      }
      res.status(500).json({ success: false, message: err.sqlMessage || err.message || 'Server error while updating entity' });
    }
  }
);

/* =========================================
   DELETE ENTITY
========================================= */
router.delete('/:id', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    const [result] = await pool.query('DELETE FROM entities WHERE id = ?', [id]);

    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'Entity not found' });
    }

    res.json({ success: true, message: 'Entity deleted successfully' });
  } catch (err) {
    console.error('Delete Entity Error:', err);
    res.status(500).json({ success: false, message: err.sqlMessage || err.message || 'Server error while deleting entity' });
  }
});

module.exports = router;
