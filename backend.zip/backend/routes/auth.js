const express = require("express");
const router = express.Router();
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { body, validationResult } = require("express-validator");
const pool = require("../config/database");
const authMiddleware = require("../middleware/auth");
require("dotenv").config();

const getUsersColumnSet = async () => {
  const [rows] = await pool.query('SHOW COLUMNS FROM users');
  return new Set(rows.map((r) => r.Field));
};

const getAnyTenantId = async () => {
  const [rows] = await pool.query('SELECT id FROM tenants ORDER BY id ASC LIMIT 1');
  return rows.length ? rows[0].id : null;
};

const ensureTenantId = async () => {
  const existing = await getAnyTenantId();
  if (existing) return existing;

  const [columns] = await pool.query('SHOW COLUMNS FROM tenants');
  const required = columns.filter((c) => {
    const hasDefault = c.Default !== null;
    const allowsNull = c.Null === 'YES';
    const autoIncrement = String(c.Extra || '').toLowerCase().includes('auto_increment');
    return !hasDefault && !allowsNull && !autoIncrement;
  });

  const insertColumns = [];
  const insertValues = [];
  const placeholders = [];

  for (const col of required) {
    const field = String(col.Field || '').toLowerCase();
    const type = String(col.Type || '').toLowerCase();

    insertColumns.push(col.Field);

    if (field.includes('name') || field.includes('title')) {
      insertValues.push('Default Tenant');
      placeholders.push('?');
      continue;
    }

    if (field.includes('status')) {
      insertValues.push('active');
      placeholders.push('?');
      continue;
    }

    if (type.includes('date') || type.includes('time') || type.includes('timestamp')) {
      placeholders.push('NOW()');
      continue;
    }

    if (type.includes('int') || type.includes('decimal') || type.includes('float') || type.includes('double')) {
      insertValues.push(1);
      placeholders.push('?');
      continue;
    }

    insertValues.push('default');
    placeholders.push('?');
  }

  if (insertColumns.length) {
    const sql = `INSERT INTO tenants (${insertColumns.join(', ')}) VALUES (${placeholders.join(', ')})`;
    const [result] = await pool.query(sql, insertValues);
    return result.insertId || null;
  }

  const [result] = await pool.query('INSERT INTO tenants () VALUES ()');
  return result.insertId || null;
};

/* ===============================
   REGISTER
================================= */
router.post(
  '/register',
  [
    body('name').trim().notEmpty().withMessage('Name is required'),
    body('email').trim().isEmail().withMessage('Valid email is required'),
    body('password')
      .isLength({ min: 6 })
      .withMessage('Password must be at least 6 characters'),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          errors: errors.array(),
        });
      }

      const { name, email, password, contact } = req.body;

      // Normalize email
      const normalizedEmail = email.trim().toLowerCase();

      // Check if user already exists
      const [existingRows] = await pool.query(
        'SELECT id FROM users WHERE email = ? LIMIT 1',
        [normalizedEmail]
      );

      if (existingRows.length > 0) {
        return res.status(400).json({
          success: false,
          message: 'User already exists',
        });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(password, 10);

      // Insert user (tenant-agnostic; only include existing columns)
      const columns = await getUsersColumnSet();
      const insertColumns = [];
      const values = [];
      const placeholders = [];

      if (columns.has('name')) {
        insertColumns.push('name');
        values.push(name.trim());
        placeholders.push('?');
      }
      if (columns.has('email')) {
        insertColumns.push('email');
        values.push(normalizedEmail);
        placeholders.push('?');
      }
      if (columns.has('password')) {
        insertColumns.push('password');
        values.push(hashedPassword);
        placeholders.push('?');
      }
      if (columns.has('contact')) {
        insertColumns.push('contact');
        values.push(contact || null);
        placeholders.push('?');
      }
      if (columns.has('status')) {
        insertColumns.push('status');
        values.push('active');
        placeholders.push('?');
      }
      if (columns.has('tenant_id')) {
        const tenantId = await ensureTenantId();
        if (!tenantId) {
          return res.status(500).json({
            success: false,
            message: 'Failed to resolve tenant for registration',
          });
        }
        insertColumns.push('tenant_id');
        values.push(tenantId);
        placeholders.push('?');
      }

      const [result] = await pool.query(
        `INSERT INTO users (${insertColumns.join(', ')}) VALUES (${placeholders.join(', ')})`,
        values
      );

      // Generate JWT token
      if (!process.env.JWT_SECRET) {
        return res.status(500).json({
          success: false,
          message: 'JWT_SECRET is not set in .env',
        });
      }

      const token = jwt.sign(
        { id: result.insertId, email: normalizedEmail },
        process.env.JWT_SECRET,
        { expiresIn: '24h' }
      );

      // Return response
      return res.status(201).json({
        success: true,
        message: 'User registered successfully',
        token,
        user: {
          id: result.insertId,
          name: name.trim(),
          email: normalizedEmail,
          contact: contact || null,
          status: 'active',
        },
      });
    } catch (error) {
      console.error('Register Error:', error.stack || error);

      return res.status(500).json({
        success: false,
        message: 'Internal Server Error',
        error: error.message || 'Unknown error',
      });
    }
  }
);
/* ===============================
   LOGIN
================================= */
router.post(
  "/login",
  [
    body("email").trim().isEmail().withMessage("Valid email is required"),
    body("password").notEmpty().withMessage("Password is required"),
  ],
  async (req, res) => {
    try {
      const invalidCredentialsMessage = "Invalid email or password";
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          errors: errors.array(),
        });
      }

      const { email, password } = req.body;
      const normalizedEmail = email.trim().toLowerCase();

      const [users] = await pool.query(
        "SELECT * FROM users WHERE email = ? ORDER BY id DESC LIMIT 1",
        [normalizedEmail]
      );

      if (users.length === 0) {
        return res.status(401).json({
          success: false,
          message: invalidCredentialsMessage,
        });
      }

      const user = users[0];

      // Check password
      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
        return res.status(401).json({
          success: false,
          message: invalidCredentialsMessage,
        });
      }

      // Check account status
      if (user.status !== "active") {
        return res.status(403).json({
          success: false,
          message: "Account is inactive",
        });
      }

      // Mark user online on successful login (best effort).
      try {
        await pool.query("UPDATE users SET is_online = 1 WHERE id = ?", [user.id]);
      } catch (_presenceErr) {
        // Ignore presence update errors to avoid blocking auth.
      }

      // Ensure JWT secret exists
      if (!process.env.JWT_SECRET) {
        console.error("JWT_SECRET missing in .env");
        return res.status(500).json({
          success: false,
          message: "Server configuration error",
        });
      }

      // Generate token
      const token = jwt.sign(
        {
          id: user.id,
          email: user.email,
        },
        process.env.JWT_SECRET,
        { expiresIn: "24h" }
      );

      return res.status(200).json({
        success: true,
        message: "Login successful",
        token, // top-level token for frontend
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          status: user.status,
        },
      });
    } catch (error) {
      console.error("Login Error:", error);
      return res.status(500).json({
        success: false,
        message: "Internal Server Error",
      });
    }
  }
);

/* ===============================
   LOGOUT
================================= */
router.post("/logout", authMiddleware, async (req, res) => {
  try {
    const userId = req.user?.id;

    if (userId) {
      try {
        await pool.query("UPDATE users SET is_online = 0 WHERE id = ?", [userId]);
      } catch (_presenceErr) {
        // Ignore presence update errors to keep logout non-blocking.
      }
    }

    return res.status(200).json({
      success: true,
      message: "Logged out",
    });
  } catch (error) {
    console.error("Logout Error:", error);
    return res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
});

module.exports = router;


