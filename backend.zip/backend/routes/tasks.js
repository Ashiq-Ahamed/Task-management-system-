const express = require("express");
const router = express.Router();
const pool = require("../config/database");
const authMiddleware = require("../middleware/auth");

const getAnyTenantId = async () => {
  const [rows] = await pool.query("SELECT id FROM tenants ORDER BY id ASC LIMIT 1");
  return rows.length ? rows[0].id : null;
};

const ensureTenantId = async () => {
  const existing = await getAnyTenantId();
  if (existing) return existing;

  const [columns] = await pool.query("SHOW COLUMNS FROM tenants");
  const required = columns.filter((c) => {
    const hasDefault = c.Default !== null;
    const allowsNull = c.Null === "YES";
    const autoIncrement = String(c.Extra || "").toLowerCase().includes("auto_increment");
    return !hasDefault && !allowsNull && !autoIncrement;
  });

  const insertColumns = [];
  const insertValues = [];
  const placeholders = [];

  for (const col of required) {
    const field = String(col.Field || "").toLowerCase();
    const type = String(col.Type || "").toLowerCase();

    insertColumns.push(col.Field);

    if (field.includes("name") || field.includes("title")) {
      insertValues.push("Default Tenant");
      placeholders.push("?");
      continue;
    }

    if (field.includes("status")) {
      insertValues.push("active");
      placeholders.push("?");
      continue;
    }

    if (type.includes("date") || type.includes("time") || type.includes("timestamp")) {
      placeholders.push("NOW()");
      continue;
    }

    if (type.includes("int") || type.includes("decimal") || type.includes("float") || type.includes("double")) {
      insertValues.push(1);
      placeholders.push("?");
      continue;
    }

    insertValues.push("default");
    placeholders.push("?");
  }

  if (insertColumns.length) {
    const sql = `INSERT INTO tenants (${insertColumns.join(", ")}) VALUES (${placeholders.join(", ")})`;
    const [result] = await pool.query(sql, insertValues);
    return result.insertId || null;
  }

  const [result] = await pool.query("INSERT INTO tenants () VALUES ()");
  return result.insertId || null;
};

// ==========================
// VALIDATION CONSTANTS
// ==========================
const VALID_STATUSES = ["pending", "in_progress", "completed"];
const VALID_PRIORITIES = ["low", "medium", "high"];
const MAX_TITLE_LENGTH = 255;
const MAX_DESCRIPTION_LENGTH = 5000;

// ==========================
// HELPER FUNCTIONS
// ==========================
const sanitizeString = (str, maxLength) => 
  str?.trim().slice(0, maxLength).replace(/[<>]/g, '') || '';

const isValidISODate = (date) => {
  if (!date) return true;
  const d = new Date(date);
  return d instanceof Date && !isNaN(d) && /^\d{4}-\d{2}-\d{2}/.test(date);
};

const validateStatus = (status) => VALID_STATUSES.includes(status);
const validatePriority = (priority) => VALID_PRIORITIES.includes(priority);
const normalizeStatusInput = (status) => {
  const normalized = String(status || "").trim().toLowerCase();
  if (!normalized || normalized === "all" || normalized === "all status") return "";
  if (normalized === "open") return "pending";
  if (normalized === "closed") return "completed";
  if (normalized === "in-progress") return "in_progress";
  return normalized;
};
const toDbStatus = (normalizedStatus) => {
  if (normalizedStatus === "pending") return "open";
  if (normalizedStatus === "completed") return "closed";
  return normalizedStatus;
};
const toUiStatus = (dbStatus) => {
  const normalized = String(dbStatus || "").trim().toLowerCase();
  if (!normalized || normalized === "open") return "pending";
  if (normalized === "closed") return "completed";
  return normalized;
};
const buildTaskAccessCondition = (alias = "t", requireEdit = false) => `
(
  ${alias}.created_by = ? OR
  ${alias}.assigned_to = ? OR
  EXISTS (
    SELECT 1
    FROM permissions p
    WHERE p.task_id = ${alias}.id
      AND (
        (p.user_id = ? AND ${requireEdit ? "p.can_edit = 1" : "(p.can_view = 1 OR p.can_edit = 1)"}) OR
        (${alias}.group_id IS NOT NULL AND p.group_id = ${alias}.group_id AND ${requireEdit ? "p.can_edit = 1" : "(p.can_view = 1 OR p.can_edit = 1)"})
      )
  )
)`;
const buildTaskAccessParams = (userId) => [userId, userId, userId];
const canAccessTask = async ({ taskId, userId, requireEdit = false }) => {
  const accessSql = buildTaskAccessCondition("t", requireEdit);
  const accessParams = buildTaskAccessParams(userId);
  const [rows] = await pool.query(
    `SELECT t.id FROM tasks t WHERE t.id = ? AND ${accessSql} LIMIT 1`,
    [taskId, ...accessParams]
  );
  return rows.length > 0;
};
const normalizeTaskStatusValue = (status, fallback = "pending") => {
  const normalized = normalizeStatusInput(status);
  return normalized && validateStatus(normalized) ? normalized : fallback;
};

/* ==========================
   TASK CONTROLLER (SECURE + ENHANCED)
========================== */
const taskController = {

  /* ==========================
     GET TASKS (with pagination & filtering + total count)
  ========================== */
  getTasks: async (req, res) => {
    try {
      const { id: user_id } = req.user;
      const { page = 1, limit = 15, status, assigned_to, priority, search } = req.query;
      
      // Validate pagination
      const pageNum = Math.max(1, parseInt(page) || 1);
      const limitNum = Math.min(50, Math.max(1, parseInt(limit) || 15));
      const offset = (pageNum - 1) * limitNum;

      let whereConditions = [];
      let params = [];
      whereConditions.push(buildTaskAccessCondition("t", false));
      params.push(...buildTaskAccessParams(user_id));

      const normalizedStatus = normalizeStatusInput(status);
      if (normalizedStatus && validateStatus(normalizedStatus)) {

        if (normalizedStatus === "pending") {
          // Backward compatibility for old rows where status was saved as empty/open.
          whereConditions.push("(t.status = ? OR t.status = ? OR t.status = '')");
          params.push("pending", "open");
        } else if (normalizedStatus === "completed") {
          whereConditions.push("(t.status = ? OR t.status = ?)");
          params.push("completed", "closed");
        } else {
          whereConditions.push("t.status = ?");
          params.push(normalizedStatus);
        }
      }
      if (priority && validatePriority(priority)) {
        whereConditions.push("t.priority = ?");
        params.push(priority);
      }
      if (assigned_to) {
        whereConditions.push("t.assigned_to = ?");
        params.push(assigned_to);
      }
      if (search?.trim()) {
        whereConditions.push("(t.title LIKE ? OR t.description LIKE ?)");
        const searchTerm = `%${sanitizeString(search, 100)}%`;
        params.push(searchTerm, searchTerm);
      }

      const whereClause = whereConditions.join(" AND ");

      // Count total
      const countQuery = `SELECT COUNT(*) as total FROM tasks t WHERE ${whereClause}`;
      const [[{ total }]] = await pool.query(countQuery, params);

      // Fetch tasks with assignee and creator
      const query = `
        SELECT t.*, 
               u.name as assigned_to_name, 
               creator.name as created_by_name,
               (SELECT COUNT(*) FROM subtasks WHERE task_id = t.id AND status NOT IN ('closed','completed')) as pending_subtasks
        FROM tasks t 
        LEFT JOIN users u ON t.assigned_to = u.id 
        LEFT JOIN users creator ON t.created_by = creator.id 
        WHERE ${whereClause}
        ORDER BY t.created_at DESC 
        LIMIT ? OFFSET ?
      `;
      params.push(limitNum, offset);

      const [tasks] = await pool.query(query, params);
      const mappedTasks = tasks.map((task) => ({
        ...task,
        status: toUiStatus(task.status),
      }));

      res.json({
        success: true,
        data: mappedTasks,
        pagination: {
          page: pageNum,
          limit: limitNum,
          total,
          pages: Math.ceil(total / limitNum)
        }
      });
    } catch (err) {
      console.error("[getTasks] Error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  },

  /* ==========================
     GET SINGLE TASK (with subtasks + comments + assignee name)
  ========================== */
  getSingleTask: async (req, res) => {
    try {
      const { id: user_id } = req.user;
      const { id } = req.params;

      const accessSql = buildTaskAccessCondition("t", false);
      const accessParams = buildTaskAccessParams(user_id);
      const [[task]] = await pool.query(
        `SELECT t.*, u.name as assigned_to_name, creator.name as created_by_name
         FROM tasks t
         LEFT JOIN users u ON t.assigned_to = u.id
         LEFT JOIN users creator ON t.created_by = creator.id
         WHERE t.id = ? AND ${accessSql}`,
        [id, ...accessParams]
      );

      if (!task) {
        return res.status(404).json({ success: false, message: "Task not found" });
      }

      // Get subtasks
      const [subtasks] = await pool.query(
        `SELECT s.id, s.task_id, s.title,
                CASE
                  WHEN s.status = 'closed' THEN 'completed'
                  WHEN s.status = 'open' OR s.status = '' OR s.status IS NULL THEN 'pending'
                  ELSE s.status
                END as status,
                s.assigned_to, s.description, s.created_at, s.updated_at,
                u.name as assigned_to_name
         FROM subtasks s 
         LEFT JOIN users u ON s.assigned_to = u.id 
         WHERE s.task_id = ? 
         ORDER BY s.created_at ASC`,
        [id]
      );

      // Get comments with user names
      const [comments] = await pool.query(
        `SELECT c.*, u.name as user_name 
         FROM comments c 
         JOIN users u ON c.user_id = u.id 
         WHERE c.task_id = ? 
         ORDER BY c.created_at DESC`,
        [id]
      );

      res.json({
        success: true,
        data: {
          ...task,
          status: toUiStatus(task.status),
          subtasks,
          comments
        }
      });
    } catch (err) {
      console.error("[getSingleTask] Error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  },

  /* ==========================
     CREATE TASK
  ========================== */
  createTask: async (req, res) => {
    try {
      const { id: created_by } = req.user;
      const {
        title, status = 'pending', assigned_to, start_date, due_date,
        entity_id, group_id, priority = 'medium', description = '',
        reminder_enabled = false, reminder_datetime = null, reminder_notify_before = 0
      } = req.body;

      // Validation
      if (!title?.trim()) {
        return res.status(400).json({ success: false, message: "Title is required" });
      }

      const cleanTitle = sanitizeString(title, MAX_TITLE_LENGTH);
      const cleanDescription = sanitizeString(description, MAX_DESCRIPTION_LENGTH);
      const tenantId = await ensureTenantId();
      if (!tenantId) {
        return res.status(500).json({ success: false, message: "Failed to resolve tenant for task creation" });
      }

      const normalizedStatus = normalizeTaskStatusValue(status, "pending");
      if (!validateStatus(normalizedStatus)) {
        return res.status(400).json({ success: false, message: "Invalid status" });
      }
      const dbStatus = toDbStatus(normalizedStatus);
      if (!validatePriority(priority)) {
        return res.status(400).json({ success: false, message: "Invalid priority" });
      }
      if (!isValidISODate(start_date) || !isValidISODate(due_date)) {
        return res.status(400).json({ success: false, message: "Invalid date format" });
      }

      const [result] = await pool.query(
        `INSERT INTO tasks 
        (tenant_id, title, status, assigned_to, start_date, due_date, entity_id, group_id, 
         priority, description, reminder_enabled, reminder_datetime, reminder_notify_before, 
         created_by, created_at, updated_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW(),NOW())`,
        [tenantId, cleanTitle, dbStatus, assigned_to || null, start_date || null, due_date || null,
         entity_id || null, group_id || null, priority, cleanDescription,
         reminder_enabled ? 1 : 0, reminder_datetime, reminder_notify_before, created_by]
      );

      res.status(201).json({ 
        success: true, 
        message: "Task created", 
        data: { id: result.insertId, title: cleanTitle, status: normalizedStatus, priority }
      });
    } catch (err) {
      console.error("[createTask] Error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  },

  /* ==========================
     UPDATE TASK
  ========================== */
  updateTask: async (req, res) => {
    try {
      const { id: user_id } = req.user;
      const { id } = req.params;

      const allowedFields = [
        'title','status','assigned_to','start_date','due_date','entity_id','group_id',
        'priority','description','reminder_enabled','reminder_datetime','reminder_notify_before'
      ];

      const updates = [];
      const values = [];

      for (const field of allowedFields) {
        if (req.body[field] !== undefined) {
          if (field === "status") {
            const normalizedStatus = normalizeTaskStatusValue(req.body[field], "pending");
            if (!validateStatus(normalizedStatus)) {
              return res.status(400).json({ success: false, message: "Invalid status" });
            }
            values.push(toDbStatus(normalizedStatus));
            updates.push(`${field} = ?`);
            continue;
          }
          if (field === "priority" && !validatePriority(req.body[field])) {
            return res.status(400).json({ success: false, message: "Invalid priority" });
          }
          if ((field === "start_date" || field === "due_date") && !isValidISODate(req.body[field])) {
            return res.status(400).json({ success: false, message: `Invalid ${field}` });
          }
          if (field === "title") {
            values.push(sanitizeString(req.body[field], MAX_TITLE_LENGTH));
          } else if (field === "description") {
            values.push(sanitizeString(req.body[field], MAX_DESCRIPTION_LENGTH));
          } else {
            values.push(req.body[field]);
          }
          updates.push(`${field} = ?`);
        }
      }

      if (updates.length === 0) {
        return res.status(400).json({ success: false, message: "No fields to update" });
      }

      values.push(id);
      values.push(...buildTaskAccessParams(user_id));

      const [result] = await pool.query(
        `UPDATE tasks SET ${updates.join(', ')}, updated_at = NOW() 
         WHERE id = ? AND ${buildTaskAccessCondition("tasks", true)}`,
        values
      );

      if (result.affectedRows === 0) {
        return res.status(404).json({ success: false, message: "Task not found" });
      }

      res.json({ success: true, message: "Task updated" });
    } catch (err) {
      console.error("[updateTask] Error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  },

  /* ==========================
     DELETE TASK (Transaction-safe)
  ========================== */
  deleteTask: async (req, res) => {
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();
      const { id: user_id } = req.user;
      const { id } = req.params;

      // Verify ownership first (locks row)
      const accessSql = buildTaskAccessCondition("tasks", true);
      const accessParams = buildTaskAccessParams(user_id);
      const [[task]] = await connection.query(
        `SELECT id FROM tasks
         WHERE id = ? AND ${accessSql}
         FOR UPDATE`,
        [id, ...accessParams]
      );
      
      if (!task) {
        await connection.rollback();
        return res.status(404).json({ success: false, message: "Task not found" });
      }

      // Cascade delete
      await connection.query('DELETE FROM subtasks WHERE task_id = ?', [id]);
      await connection.query('DELETE FROM comments WHERE task_id = ?', [id]);
      await connection.query('DELETE FROM tasks WHERE id = ?', [id]);
      
      await connection.commit();
      res.json({ success: true, message: "Task deleted" });
    } catch (err) {
      await connection.rollback();
      console.error("[deleteTask] Error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    } finally {
      connection.release();
    }
  },

  /* ==========================
     COMPLETE TASK
  ========================== */
  completeTask: async (req, res) => {
    try {
      const { id: user_id } = req.user;
      const { id } = req.params;

      const accessSql = buildTaskAccessCondition("tasks", true);
      const accessParams = buildTaskAccessParams(user_id);
      const [result] = await pool.query(
        `UPDATE tasks
         SET status = 'closed', updated_at = NOW()
         WHERE id = ? AND ${accessSql}`,
        [id, ...accessParams]
      );

      if (result.affectedRows === 0) {
        return res.status(404).json({ success: false, message: "Task not found" });
      }

      res.json({ success: true, message: "Task completed" });
    } catch (err) {
      console.error("[completeTask] Error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  },

  // ==========================
  // SUBTASKS (SECURE)
  // ==========================
  createSubtask: async (req, res) => {
    try {
      const { id: user_id } = req.user;
      const { id: task_id } = req.params;
      const { title, status = 'pending', assigned_to, description = '' } = req.body;

      if (!title?.trim()) {
        return res.status(400).json({ success: false, message: "Subtask title required" });
      }

      const normalizedStatus = normalizeTaskStatusValue(status, "pending");
      if (!validateStatus(normalizedStatus)) {
        return res.status(400).json({ success: false, message: "Invalid status" });
      }
      const dbStatus = toDbStatus(normalizedStatus);

      const cleanTitle = sanitizeString(title, MAX_TITLE_LENGTH);
      const cleanDescription = sanitizeString(description, MAX_DESCRIPTION_LENGTH);

      const taskAllowed = await canAccessTask({
        taskId: task_id,
        userId: user_id,
        requireEdit: true,
      });
      const task = taskAllowed ? { id: task_id } : null;
      if (!task) {
        return res.status(404).json({ success: false, message: "Task not found" });
      }

      const [result] = await pool.query(
        'INSERT INTO subtasks (task_id, title, status, assigned_to, description, created_at, updated_at) VALUES (?,?,?,?,?,NOW(),NOW())',
        [task_id, cleanTitle, dbStatus, assigned_to || null, cleanDescription]
      );

      res.status(201).json({ 
        success: true, 
        message: "Subtask created", 
        data: { id: result.insertId, title: cleanTitle, status: normalizedStatus }
      });
    } catch (err) {
      console.error("[createSubtask] Error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  },

  updateSubtask: async (req, res) => {
    try {
      const { id: user_id } = req.user;
      const { id: task_id, subId } = req.params;
      const updates = [];
      const values = [];

      if (req.body.title !== undefined) {
        if (!req.body.title.trim()) {
          return res.status(400).json({ success: false, message: "Title cannot be empty" });
        }
        updates.push("title = ?");
        values.push(sanitizeString(req.body.title, MAX_TITLE_LENGTH));
      }
      
      if (req.body.status) {
        const normalizedStatus = normalizeTaskStatusValue(req.body.status, "pending");
        if (!validateStatus(normalizedStatus)) {
          return res.status(400).json({ success: false, message: "Invalid status" });
        }
        updates.push("status = ?");
        values.push(toDbStatus(normalizedStatus));
      }
      
      if (req.body.assigned_to !== undefined) {
        updates.push("assigned_to = ?");
        values.push(req.body.assigned_to);
      }
      
      if (req.body.description !== undefined) {
        updates.push("description = ?");
        values.push(sanitizeString(req.body.description, MAX_DESCRIPTION_LENGTH));
      }

      if (updates.length === 0) {
        return res.status(400).json({ success: false, message: "No fields to update" });
      }

      const taskAllowed = await canAccessTask({
        taskId: task_id,
        userId: user_id,
        requireEdit: true,
      });
      if (!taskAllowed) {
        return res.status(404).json({ success: false, message: "Subtask not found or access denied" });
      }

      values.push(subId, task_id);

      const [result] = await pool.query(
        `UPDATE subtasks s
         JOIN tasks t ON s.task_id = t.id
         SET ${updates.join(', ')}, s.updated_at = NOW()
         WHERE s.id = ? AND t.id = ?`,
        values
      );

      if (result.affectedRows === 0) {
        return res.status(404).json({ success: false, message: "Subtask not found or access denied" });
      }

      res.json({ success: true, message: "Subtask updated" });
    } catch (err) {
      console.error("[updateSubtask] Error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  },

  deleteSubtask: async (req, res) => {
    try {
      const { id: user_id } = req.user;
      const { id: task_id, subId } = req.params;

      const taskAllowed = await canAccessTask({
        taskId: task_id,
        userId: user_id,
        requireEdit: true,
      });
      if (!taskAllowed) {
        return res.status(404).json({ success: false, message: "Subtask not found or access denied" });
      }

      const [result] = await pool.query(
        `DELETE s FROM subtasks s
         JOIN tasks t ON s.task_id = t.id
         WHERE s.id = ? AND t.id = ?`,
        [subId, task_id]
      );

      if (result.affectedRows === 0) {
        return res.status(404).json({ success: false, message: "Subtask not found or access denied" });
      }

      res.json({ success: true, message: "Subtask deleted" });
    } catch (err) {
      console.error("[deleteSubtask] Error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  },

  completeAllSubtasks: async (req, res) => {
    try {
      const { id: user_id } = req.user;
      const { id: task_id } = req.params;

      const taskAllowed = await canAccessTask({
        taskId: task_id,
        userId: user_id,
        requireEdit: true,
      });
      if (!taskAllowed) {
        return res.status(404).json({ success: false, message: "Task not found or access denied" });
      }

      const [result] = await pool.query(
        `UPDATE subtasks s
         JOIN tasks t ON s.task_id = t.id
         SET s.status = 'closed', s.updated_at = NOW()
         WHERE t.id = ?`,
        [task_id]
      );

      res.json({ 
        success: true, 
        message: "All subtasks completed", 
        updated: result.affectedRows 
      });
    } catch (err) {
      console.error("[completeAllSubtasks] Error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  },

  // ==========================
  // COMMENTS (SECURE)
  // ==========================
  createComment: async (req, res) => {
    try {
      const { id: user_id } = req.user;
      const { id: task_id } = req.params;
      const { content } = req.body;

      if (!content?.trim()) {
        return res.status(400).json({ success: false, message: "Comment cannot be empty" });
      }

      const cleanContent = sanitizeString(content, 2000);

      const taskAllowed = await canAccessTask({
        taskId: task_id,
        userId: user_id,
        requireEdit: false,
      });
      const task = taskAllowed ? { id: task_id } : null;
      if (!task) {
        return res.status(404).json({ success: false, message: "Task not found" });
      }

      const [result] = await pool.query(
        'INSERT INTO comments (task_id, user_id, content, created_at) VALUES (?,?,?,NOW())',
        [task_id, user_id, cleanContent]
      );

      res.status(201).json({ 
        success: true, 
        message: "Comment added", 
        data: { id: result.insertId, content: cleanContent }
      });
    } catch (err) {
      console.error("[createComment] Error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  },

  deleteComment: async (req, res) => {
    try {
      const { id: user_id } = req.user;
      const { id: task_id, commentId } = req.params;

      // Allow deletion if user owns comment OR user owns task (simplified logic)
      const [result] = await pool.query(
        `DELETE c FROM comments c
         JOIN tasks t ON c.task_id = t.id
         WHERE c.id = ? AND t.id = ? 
         AND (c.user_id = ? OR t.created_by = ?)`,
        [commentId, task_id, user_id, user_id]
      );

      if (result.affectedRows === 0) {
        return res.status(404).json({ success: false, message: "Comment not found or access denied" });
      }

      res.json({ success: true, message: "Comment deleted" });
    } catch (err) {
      console.error("[deleteComment] Error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
};

/* ==========================
   TASK PERMISSIONS
========================== */
const permissionsController = {
  list: async (req, res) => {
    try {
      const { id: user_id } = req.user;
      const { id: task_id } = req.params;

      const canEditTask = await canAccessTask({
        taskId: task_id,
        userId: user_id,
        requireEdit: true,
      });
      if (!canEditTask) {
        return res.status(403).json({ success: false, message: "Access denied" });
      }

      const [rows] = await pool.query(
        `SELECT p.id, p.task_id, p.user_id, p.group_id, p.can_view, p.can_edit, p.created_at,
                u.name AS user_name, u.email AS user_email, g.name AS group_name
         FROM permissions p
         LEFT JOIN users u ON p.user_id = u.id
         LEFT JOIN groups g ON p.group_id = g.id
         WHERE p.task_id = ?
         ORDER BY p.created_at DESC`,
        [task_id]
      );

      return res.json({ success: true, data: rows });
    } catch (err) {
      console.error("[listPermissions] Error:", err);
      return res.status(500).json({ success: false, message: "Server error" });
    }
  },
  upsert: async (req, res) => {
    try {
      const { id: user_id } = req.user;
      const { id: task_id } = req.params;
      const { target_user_id, target_group_id, can_view = 1, can_edit = 0 } = req.body || {};

      const canEditTask = await canAccessTask({
        taskId: task_id,
        userId: user_id,
        requireEdit: true,
      });
      if (!canEditTask) {
        return res.status(403).json({ success: false, message: "Access denied" });
      }

      const targetUserId = target_user_id ? Number(target_user_id) : null;
      const targetGroupId = target_group_id ? Number(target_group_id) : null;

      if (!targetUserId && !targetGroupId) {
        return res.status(400).json({ success: false, message: "target_user_id or target_group_id is required" });
      }
      if (targetUserId && targetGroupId) {
        return res.status(400).json({ success: false, message: "Provide either target_user_id or target_group_id, not both" });
      }

      if (targetUserId) {
        const [userRows] = await pool.query(
          "SELECT id FROM users WHERE id = ? LIMIT 1",
          [targetUserId]
        );
        if (!userRows.length) {
          return res.status(400).json({ success: false, message: "Invalid target_user_id" });
        }
      }

      if (targetGroupId) {
        const [groupRows] = await pool.query(
          "SELECT id FROM groups WHERE id = ? LIMIT 1",
          [targetGroupId]
        );
        if (!groupRows.length) {
          return res.status(400).json({ success: false, message: "Invalid target_group_id" });
        }
      }

      const effectiveCanEdit = Number(can_edit) === 1 ? 1 : 0;
      const effectiveCanView = effectiveCanEdit ? 1 : (Number(can_view) === 1 ? 1 : 0);

      if (!effectiveCanView && !effectiveCanEdit) {
        return res.status(400).json({ success: false, message: "At least one permission must be enabled" });
      }

      if (targetUserId) {
        await pool.query(
          "DELETE FROM permissions WHERE task_id = ? AND user_id = ?",
          [task_id, targetUserId]
        );
      } else {
        await pool.query(
          "DELETE FROM permissions WHERE task_id = ? AND group_id = ?",
          [task_id, targetGroupId]
        );
      }

      const [result] = await pool.query(
        `INSERT INTO permissions (task_id, user_id, group_id, can_view, can_edit)
         VALUES (?, ?, ?, ?, ?)`,
        [task_id, targetUserId, targetGroupId, effectiveCanView, effectiveCanEdit]
      );

      return res.status(201).json({
        success: true,
        message: "Permission saved",
        data: {
          id: result.insertId,
          task_id: Number(task_id),
          user_id: targetUserId,
          group_id: targetGroupId,
          can_view: effectiveCanView,
          can_edit: effectiveCanEdit,
        },
      });
    } catch (err) {
      console.error("[upsertPermission] Error:", err);
      return res.status(500).json({ success: false, message: "Server error" });
    }
  },
  remove: async (req, res) => {
    try {
      const { id: user_id } = req.user;
      const { id: task_id, permissionId } = req.params;

      const canEditTask = await canAccessTask({
        taskId: task_id,
        userId: user_id,
        requireEdit: true,
      });
      if (!canEditTask) {
        return res.status(403).json({ success: false, message: "Access denied" });
      }

      const [result] = await pool.query(
        "DELETE FROM permissions WHERE id = ? AND task_id = ?",
        [permissionId, task_id]
      );

      if (!result.affectedRows) {
        return res.status(404).json({ success: false, message: "Permission not found" });
      }

      return res.json({ success: true, message: "Permission removed" });
    } catch (err) {
      console.error("[deletePermission] Error:", err);
      return res.status(500).json({ success: false, message: "Server error" });
    }
  }
};

/* ==========================
   ROUTES
========================== */
router.get("/", authMiddleware, taskController.getTasks);
router.get("/:id", authMiddleware, taskController.getSingleTask);
router.post("/", authMiddleware, taskController.createTask);
router.put("/:id", authMiddleware, taskController.updateTask);
router.delete("/:id", authMiddleware, taskController.deleteTask);
router.put("/:id/complete", authMiddleware, taskController.completeTask);

// Subtasks
router.post("/:id/subtasks", authMiddleware, taskController.createSubtask);
router.put("/:id/subtasks/complete-all", authMiddleware, taskController.completeAllSubtasks);
router.put("/:id/subtasks/:subId", authMiddleware, taskController.updateSubtask);
router.delete("/:id/subtasks/:subId", authMiddleware, taskController.deleteSubtask);

// Comments
router.post("/:id/comments", authMiddleware, taskController.createComment);
router.delete("/:id/comments/:commentId", authMiddleware, taskController.deleteComment);

// Permissions
router.get("/:id/permissions", authMiddleware, permissionsController.list);
router.post("/:id/permissions", authMiddleware, permissionsController.upsert);
router.delete("/:id/permissions/:permissionId", authMiddleware, permissionsController.remove);

module.exports = router;
