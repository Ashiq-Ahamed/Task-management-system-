﻿const express = require('express');
const router = express.Router();
const pool = require('../config/database');
const authMiddleware = require('../middleware/auth');
const bcrypt = require('bcryptjs');

const REQUIRED_USER_COLUMNS = ['id', 'name', 'email'];
const OPTIONAL_USER_COLUMNS = ['contact', 'status', 'created_at', 'is_online'];

const getUsersTableColumns = async () => {
  const [columns] = await pool.query(
    `SELECT COLUMN_NAME
     FROM INFORMATION_SCHEMA.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE()
       AND TABLE_NAME = 'users'`
  );

  return new Set(columns.map((c) => c.COLUMN_NAME));
};

const buildUserSelectColumns = (columnsSet) => {
  const selected = REQUIRED_USER_COLUMNS.filter((col) => columnsSet.has(col));

  if (selected.length !== REQUIRED_USER_COLUMNS.length) {
    throw new Error('users table is missing required columns (id, name, email)');
  }

  OPTIONAL_USER_COLUMNS.forEach((col) => {
    if (columnsSet.has(col)) selected.push(col);
  });

  return selected;
};

const normalizeUserResponse = (user) => ({
  ...user,
  contact: user.contact ?? null,
  status: user.status ?? 'active',
  created_at: user.created_at ?? null,
  is_online: user.is_online ?? 0
});

const getAnyTenantId = async () => {
  const [rows] = await pool.query('SELECT id FROM tenants ORDER BY id ASC LIMIT 1');
  return rows.length ? rows[0].id : null;
};

const ensureTenantId = async () => {
  const existing = await getAnyTenantId();
  if (existing) return existing;

  const [columns] = await pool.query('SHOW COLUMNS FROM tenants');
  const required = columns.filter((c) => {
    const hasDefault = c.Default !== null;
    const allowsNull = c.Null === 'YES';
    const autoIncrement = String(c.Extra || '').toLowerCase().includes('auto_increment');
    return !hasDefault && !allowsNull && !autoIncrement;
  });

  const insertColumns = [];
  const insertValues = [];
  const placeholders = [];

  for (const col of required) {
    const field = String(col.Field || '').toLowerCase();
    const type = String(col.Type || '').toLowerCase();

    insertColumns.push(col.Field);

    if (field.includes('name') || field.includes('title')) {
      insertValues.push('Default Tenant');
      placeholders.push('?');
      continue;
    }

    if (field.includes('status')) {
      insertValues.push('active');
      placeholders.push('?');
      continue;
    }

    if (type.includes('date') || type.includes('time') || type.includes('timestamp')) {
      placeholders.push('NOW()');
      continue;
    }

    if (type.includes('int') || type.includes('decimal') || type.includes('float') || type.includes('double')) {
      insertValues.push(1);
      placeholders.push('?');
      continue;
    }

    insertValues.push('default');
    placeholders.push('?');
  }

  if (insertColumns.length) {
    const sql = `INSERT INTO tenants (${insertColumns.join(', ')}) VALUES (${placeholders.join(', ')})`;
    const [result] = await pool.query(sql, insertValues);
    return result.insertId || null;
  }

  const [result] = await pool.query('INSERT INTO tenants () VALUES ()');
  return result.insertId || null;
};

/* ======================================================
   GET ALL USERS (Tenant Based)
====================================================== */
router.get('/', authMiddleware, async (req, res) => {
  try {
    const columnsSet = await getUsersTableColumns();
    const selectedColumns = buildUserSelectColumns(columnsSet);
    const orderBy = columnsSet.has('created_at') ? 'created_at DESC' : 'id DESC';

    const [users] = await pool.query(
      `SELECT ${selectedColumns.join(', ')}
       FROM users
       ORDER BY ${orderBy}`
    );

    return res.json({
      success: true,
      data: users.map(normalizeUserResponse)
    });
  } catch (error) {
    console.error('Get Users Error:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal Server Error'
    });
  }
});

/* ======================================================
   GET SINGLE USER
====================================================== */
router.get('/:id', authMiddleware, async (req, res) => {
  try {
    const id = Number(req.params.id);

    if (isNaN(id)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid request'
      });
    }

    const columnsSet = await getUsersTableColumns();
    const selectedColumns = buildUserSelectColumns(columnsSet);

    const [rows] = await pool.query(
      `SELECT ${selectedColumns.join(', ')}
       FROM users
       WHERE id = ?`,
      [id]
    );

    if (rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    return res.json({
      success: true,
      data: normalizeUserResponse(rows[0])
    });
  } catch (error) {
    console.error('Get User Error:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal Server Error'
    });
  }
});

/* ======================================================
   CREATE USER (Tenant Based)
====================================================== */
router.post('/', authMiddleware, async (req, res) => {
  try {
    const { name, email, password, contact, status } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Required fields missing'
      });
    }

    const normalizedName = String(name).trim();
    const normalizedEmail = String(email).trim().toLowerCase();

    if (!normalizedName || !normalizedEmail) {
      return res.status(400).json({
        success: false,
        message: 'Required fields missing'
      });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const columnsSet = await getUsersTableColumns();
    const insertColumns = [];
    const values = [];
    const placeholders = [];

    if (columnsSet.has('name')) {
      insertColumns.push('name');
      values.push(normalizedName);
      placeholders.push('?');
    }
    if (columnsSet.has('email')) {
      insertColumns.push('email');
      values.push(normalizedEmail);
      placeholders.push('?');
    }
    if (columnsSet.has('password')) {
      insertColumns.push('password');
      values.push(hashedPassword);
      placeholders.push('?');
    }
    if (columnsSet.has('contact')) {
      insertColumns.push('contact');
      values.push(contact || null);
      placeholders.push('?');
    }
    if (columnsSet.has('status')) {
      insertColumns.push('status');
      values.push(status || 'active');
      placeholders.push('?');
    }
    if (columnsSet.has('tenant_id')) {
      const tenantId = await ensureTenantId();
      if (!tenantId) {
        return res.status(500).json({
          success: false,
          message: 'Failed to resolve tenant for user creation'
        });
      }
      insertColumns.push('tenant_id');
      values.push(tenantId);
      placeholders.push('?');
    }

    if (!insertColumns.length) {
      return res.status(500).json({
        success: false,
        message: 'users table has no insertable columns'
      });
    }

    await pool.query(
      `INSERT INTO users (${insertColumns.join(', ')}) VALUES (${placeholders.join(', ')})`,
      values
    );

    return res.status(201).json({
      success: true,
      message: 'User created successfully'
    });
  } catch (error) {
    console.error('Create User Error:', error);
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({
        success: false,
        message: 'User with this email already exists'
      });
    }
    if (error.code === 'ER_NO_SUCH_TABLE' && error.sqlMessage?.includes("'tenants'")) {
      return res.status(500).json({
        success: false,
        message: "users.tenant_id exists, but tenants table is missing"
      });
    }
    if (error.code === 'ER_NO_DEFAULT_FOR_FIELD' && error.sqlMessage?.includes("'tenant_id'")) {
      return res.status(500).json({
        success: false,
        message: 'Database schema requires tenant_id for users, but tenant resolution failed'
      });
    }
    if (error.code === 'ER_NO_DEFAULT_FOR_FIELD') {
      const fieldMatch = String(error.sqlMessage || '').match(/'([^']+)'/);
      const fieldName = fieldMatch?.[1] || 'unknown';
      return res.status(500).json({
        success: false,
        message: `users.${fieldName} is required in DB schema but not handled by API`
      });
    }
    return res.status(500).json({
      success: false,
      message: error.sqlMessage || error.message || 'Internal Server Error'
    });
  }
});

/* ======================================================
   UPDATE USER
====================================================== */
router.put('/:id', authMiddleware, async (req, res) => {
  try {
    const id = Number(req.params.id);
    const { name, email, password, contact, status } = req.body;

    if (isNaN(id)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid request'
      });
    }

    let query = `
      UPDATE users
      SET name = ?, email = ?, contact = ?, status = ?
      WHERE id = ?
    `;
    let values = [name, email, contact || null, status, id];

    if (password) {
      const hashedPassword = await bcrypt.hash(password, 10);
      query = `
        UPDATE users
        SET name = ?, email = ?, password = ?, contact = ?, status = ?
        WHERE id = ?
      `;
      values = [name, email, hashedPassword, contact || null, status, id];
    }

    const [result] = await pool.query(query, values);

    if (result.affectedRows === 0) {
      return res.status(404).json({
        success: false,
        message: 'User not found or not authorized'
      });
    }

    return res.json({
      success: true,
      message: 'User updated successfully'
    });
  } catch (error) {
    console.error('Update User Error:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal Server Error'
    });
  }
});

/* ======================================================
   DELETE USER
====================================================== */
router.delete('/:id', authMiddleware, async (req, res) => {
  try {
    const id = Number(req.params.id);

    if (isNaN(id)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid request'
      });
    }

    const [result] = await pool.query(
      `DELETE FROM users WHERE id = ?`,
      [id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({
        success: false,
        message: 'User not found or not authorized'
      });
    }

    return res.json({
      success: true,
      message: 'User deleted successfully'
    });
  } catch (error) {
    console.error('Delete User Error:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal Server Error'
    });
  }
});

module.exports = router;
