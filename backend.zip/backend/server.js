const express = require("express");
const cors = require("cors");
require("dotenv").config();

// Import database (auto-connect on load)
require("./config/database");

// Import Routes
const authRoutes = require("./routes/auth");
const taskRoutes = require("./routes/tasks");
const userRoutes = require("./routes/users");
const entityRoutes = require("./routes/entities");
const groupRoutes = require("./routes/groups");

const app = express();

/* =====================================
   GLOBAL MIDDLEWARE
===================================== */
const defaultAllowedOrigins = [
  "http://localhost:3000",
  "http://127.0.0.1:3000",
  "http://localhost:3001",
  "http://127.0.0.1:3001",
  "http://localhost:5173",
  "http://127.0.0.1:5173",
];

const envAllowedOrigins = String(process.env.CORS_ORIGINS || "")
  .split(",")
  .map((origin) => origin.trim())
  .filter(Boolean);

const allowedOrigins = [...new Set([...defaultAllowedOrigins, ...envAllowedOrigins])];
const normalizeOrigin = (value = "") => value.trim().replace(/\/$/, "");

app.use(cors({
  origin: function (origin, callback) {
    if (!origin) return callback(null, true); // Postman, curl

    const normalizedOrigin = normalizeOrigin(origin);
    const normalizedAllowedOrigins = allowedOrigins.map(normalizeOrigin);
    const isLocalhostDevOrigin = /^https?:\/\/(localhost|127\.0\.0\.1):\d+$/.test(normalizedOrigin);

    if (!normalizedAllowedOrigins.includes(normalizedOrigin) && !isLocalhostDevOrigin) {
      return callback(new Error(`CORS policy does not allow access from origin: ${origin}`), false);
    }
    return callback(null, true);
  },
  credentials: true,
}));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

/* =====================================
   API ROUTES
===================================== */
app.use("/api/auth", authRoutes);
app.use("/api/tasks", taskRoutes);
app.use("/api/users", userRoutes);
app.use("/api/entities", entityRoutes);
app.use("/api/groups", groupRoutes);
/* =====================================
   HEALTH CHECK
===================================== */
app.get("/api/health", (req, res) => {
  res.status(200).json({ status: "OK", message: "Server is running", timestamp: new Date() });
});

/* =====================================
   404 HANDLER
===================================== */
app.use((req, res) => {
  res.status(404).json({ message: "Route not found" });
});

/* =====================================
   GLOBAL ERROR HANDLER
===================================== */
app.use((err, req, res, next) => {
  console.error("Global Error:", err.stack || err);

  if (err instanceof Error && err.message.startsWith("CORS policy")) {
    return res.status(403).json({ message: err.message });
  }

  res.status(err.status || 500).json({ message: err.message || "Internal Server Error" });
});

/* =====================================
   START SERVER
===================================== */
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
