const jwt = require("jsonwebtoken");

const normalizeToken = (rawToken) => {
  if (typeof rawToken !== "string") return null;

  let token = rawToken.trim();
  if (!token) return null;

  // Handle accidental quoted token in header: Bearer "<token>"
  if (
    (token.startsWith('"') && token.endsWith('"')) ||
    (token.startsWith("'") && token.endsWith("'"))
  ) {
    token = token.slice(1, -1).trim();
  }

  // Handle JSON-stringified token value: "\"<token>\""
  if (token.startsWith('"')) {
    try {
      const parsed = JSON.parse(token);
      if (typeof parsed === "string") {
        token = parsed.trim();
      }
    } catch (_err) {
      // Keep original token if it's not valid JSON.
    }
  }

  return token || null;
};

const authMiddleware = (req, res, next) => {
  try {
    /* =====================================================
       GET TOKEN FROM HEADER
       Expected format:
       Authorization: Bearer <token>
    ===================================================== */
    const authHeader = req.headers.authorization || req.header("Authorization");

    const tokenMatch =
      typeof authHeader === "string"
        ? authHeader.trim().match(/^Bearer\s+(.+)$/i)
        : null;

    const token = tokenMatch ? normalizeToken(tokenMatch[1]) : null;

    if (!token) {
      return res.status(401).json({
        success: false,
        message: "No token provided",
      });
    }

    /* =====================================================
       ENSURE JWT SECRET EXISTS
    ===================================================== */
    const secret = process.env.JWT_SECRET;

    if (!secret) {
      console.error("JWT_SECRET is not defined in environment");
      return res.status(500).json({
        success: false,
        message: "Server configuration error",
      });
    }

    /* =====================================================
       VERIFY TOKEN
    ===================================================== */
    const decoded = jwt.verify(token, secret, { algorithms: ["HS256"] });

    /* =====================================================
       VALIDATE REQUIRED FIELDS
    ===================================================== */
    const validId =
      typeof decoded.id === "number" ||
      (typeof decoded.id === "string" && decoded.id.trim() !== "");

    if (!validId) {
      return res.status(401).json({
        success: false,
        message: "Invalid token structure",
      });
    }

    /* =====================================================
       ATTACH USER TO REQUEST
    ===================================================== */
    req.user = {
      id: decoded.id,
      role: decoded.role || null,
      email: decoded.email || null,
      name: decoded.name || null,
    };

    next();
  } catch (error) {
    console.error("Auth Error:", error.message);

    if (error.name === "TokenExpiredError") {
      return res.status(401).json({
        success: false,
        message: "Token expired",
      });
    }

    if (error.name === "JsonWebTokenError") {
      return res.status(401).json({
        success: false,
        message: "Invalid token",
      });
    }

    return res.status(401).json({
      success: false,
      message: "Authentication failed",
    });
  }
};

module.exports = authMiddleware;
